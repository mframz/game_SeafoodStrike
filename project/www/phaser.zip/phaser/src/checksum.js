var CHECKSUM = {
build: '13721950-ed9a-11e6-8f4f-afca70274f59'
};
module.exports = CHECKSUM;